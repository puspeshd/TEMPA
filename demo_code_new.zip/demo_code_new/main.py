from translate import Translator
import re
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import pyttsx3
import subprocess
import datetime
import speech_recognition as sr
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
import base64
import os
import traceback
from gtts import gTTS
from moviepy.editor import *
from emotions import emot_iden
import json


TOKENIZERS_PARALLELISM=True
torch.set_default_device("cuda")
model_chat = AutoModelForCausalLM.from_pretrained("microsoft/phi-2", torch_dtype="auto", trust_remote_code=True)
tokenizer_chat = AutoTokenizer.from_pretrained("microsoft/phi-2", trust_remote_code=True)

try:
 os.remove("emotion.txt")
except:
    pass
app = Flask(__name__)

# Load model and tokenizer at the beginning



def encode_video_base64(file_path):
    with open(file_path, 'rb') as file:
        encoded_video = base64.b64encode(file.read()).decode('utf-8')
    return encoded_video

@app.route('/your_endpoint', methods=['POST'])
def process_request():
    try:
        text0 = request.form.get('text')
        print("got some")
        # Check if the 'audio' file part is present in the request
        if 'audio' not in request.files:
            traceback.print_exc()
            return jsonify({'error': 'No audio file provided'}), 400

        audio_file = request.files['audio']

        # Check if the file is allowed and save it
        if audio_file:
            filename = secure_filename(audio_file.filename)
            audio_file.save(filename)
            r = sr.Recognizer()
            with sr.AudioFile(filename) as source:
                audio_data = r.record(source)
                try:
                    with open("lang.txt","r") as language:
                        lang=language.read()
                        #print(lang)
                except:
                    traceback.print_exc()
                    lang = "en"     
                print(lang,"THIS IS THE LANGUAGE BEEN USED")       
                text1 = r.recognize_google(audio_data,language=lang)
            print("TEXT FROM FLUTTER ", text1)
            
            with open("chat_history.txt","r") as filowa:
                previoustext=filowa.read()
            translator=Translator(to_lang='en',from_lang=lang)
            text1=translator.translate(text1)
            print(text1,"TRANSLATED")
            try:
                with open("emotion.txt","r") as emotion:
                    emot_identified=emotion.read()
            except:
                emot_identified="neutral"        
            

            if(len(previoustext)>1):
              inputs = tokenizer_chat(f"AI ASSISTANT's name is Mariane, a 23-year-old female smart art gallery guide from Blue Pace company. This chat is inside the company's app discussing art. Customers can interact with artists' works.Answer should be around 100 tokens. Customer's mood: {emot_identified}. Customer's message: {text1}", return_tensors="pt", return_attention_mask=True)
 
            else:    
                inputs = tokenizer_chat(f"AI ASSISTANT's name is Mariane, a 23-year-old female smart art gallery guide from Blue Pace company. This chat is inside the company's app discussing art. Customers can interact with artists' works.Answer should be around 100 tokens.  Customer's mood: {emot_identified}. Customer's message: {text1}", return_tensors="pt", return_attention_mask=True)
            #input_ids = inputs["input_ids"].to(model_chat.device)
            outputs = model_chat.generate(**inputs, max_new_tokens=100)
            text = tokenizer_chat.batch_decode(outputs)[0]
            print(text,"\n COMPLETE TEXT")
            #text=json.load(text)
            #print("THIS IS JSON TEXT",text)
            text=text[:text.find("<|endoftext|>")]
            print(text)
            if(text.find("Assistant:")>-1):
                text = text[text.find("Assistant:")+10:]
            elif(text.find("AI:")>-1):
                text = text[text.find("AI:")+3:]
            else:
                text=text[text.find(":")+1:].replace(f"AI ASSISTANT's name is Mariane, a 23-year-old female smart art gallery guide from Blue Pace company. This chat is inside the company's app discussing art. Customers can interact with artists' works. Customer's mood: {emot_identified}. Customer's message: {text1}","").replace(text1,"")         
            try:
                zampa=re.finditer(":",text)
                tampa=re.finditer(".",text)
                for i in zampa:
                    spanx=i.span()[1]
                ik=1
                for j in tampa:
                    ik=ik+1
                    spany=j.span()[1]
                try:        
                    text=text[spanx:spany]
                except:
                    pass    
                    
            except:
                pass        
            print(text)
            try:
                os.remove("chat_history.txt")
            except:
                print("Except ran for text file deletion (previous prompts)")
                pass    
            with open("chat_history.txt","w") as filowa:
                previoustext=filowa.write(f"CUSTOMER's PREVIOUS QUESTION :{text1}, AI's PREVIOUS RESPONSE : {text}")
             
            translator1=Translator(to_lang=lang,from_lang="en")
            text2=translator1.translate(text)   
            tts = gTTS(text2,lang=lang, tld='co.in')
            tts.save("out_sound.mp3")
            video_clip = VideoFileClip('video.mp4')

            # Create audio clip
            audio_clip = AudioFileClip('out_sound.mp3')
            video_clip=video_clip.set_duration(audio_clip.duration)
            # Add audio to video
            final_clip = video_clip.set_audio(audio_clip)

            # Save new video with merged audio
            final_clip.write_videofile('merged_video.mp4')
            
            
            encoded_video = encode_video_base64('merged_video.mp4')
            ##torch.cuda.empty_cache()
            os.remove("out_sound.mp3")
            os.remove("myFile.wav")
            #os.remove("merged_video.mp4")
            response_data = {'text': text2, 'video_base64': encoded_video}

            return jsonify(response_data)
        else:
            return jsonify({'error': 'Invalid or no audio file provided'}), 400

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500
@app.route('/emotion_identifier', methods=['GET','POST'])
def emotion_identifier():
    try:
        # Retrieve the base64 encoded image data from the request
        image_data = request.form.get('encodedImage')
        # Decode the base64 encoded image data
        image_bytes = base64.b64decode(image_data)
        # Save the decoded image data to a file
        with open('image.jpg', 'wb') as f:
            f.write(image_bytes)
        try:
            identified_emotion=emot_iden("image.jpg")
            print(identified_emotion)
        except:
            identified_emotion="neutral"
        with open("emotion.txt", "w") as emotion:
            emotion.write(identified_emotion)

                
        
        # Perform any necessary processing on the image data here
        
        # Return a response with the text "OKEY"
        return jsonify({'response': identified_emotion}), 200
    except:
        traceback.print_exc()
        # If image data is not provided in the request, return a 400 Bad Request
        return jsonify({'error': 'Image data not provided'}), 400
@app.route('/language_identifier', methods=['POST'])
def language_identifier():
    try:
        # Retrieve the language data from the request
        language = request.form.get('language')
        print(language,"GOT THE LANGUAGE")
        try:
            os.remove("lang.txt")
        except:
            pass
        with open("lang.txt", "w") as languago:
            languago.write(language)

        # Perform any necessary processing on the language data here

        # Return a response with the language identifier
        return jsonify({'language': language}), 200
    except:
        traceback.print_exc()
        # If language data is not provided in the request, return a 400 Bad Request
        return jsonify({'error': 'Language data not provided'}), 400
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
