from flask import Flask, request, jsonify
import base64
import traceback

app = Flask(__name__)

@app.route('/emotion_identifier', methods=['GET','POST'])
def emotion_identifier():
    try:
        # Retrieve the base64 encoded image data from the request
        image_data = request.form['encodedImage']
        print(image_data, "GOT THE IMAGE DATA")
        # Decode the base64 encoded image data
        image_bytes = base64.b64decode(image_data)
        # Save the decoded image data to a file
        with open('image.jpg', 'wb') as f:
            f.write(image_bytes)
         
                
        
        # Perform any necessary processing on the image data here
        
        # Return a response with the text "OKEY"
        return jsonify({'response': 'OKEY'})
    except:
        traceback.print_exc()
        # If image data is not provided in the request, return a 400 Bad Request
        return jsonify({'error': 'Image data not provided'}), 400
@app.route('/language_identifier', methods=['POST'])
def language_identifier():
    try:
        # Retrieve the language data from the request
        language = request.form.get('language')
        print(language,"GOT THE LANGUAGE")
        # Perform any necessary processing on the language data here

        # Return a response with the language identifier
        return jsonify({'language': language}), 200
    except:
        traceback.print_exc()
        # If language data is not provided in the request, return a 400 Bad Request
        return jsonify({'error': 'Language data not provided'}), 400
if __name__ == '__main__':
    app.run("0.0.0.0",debug=True)
